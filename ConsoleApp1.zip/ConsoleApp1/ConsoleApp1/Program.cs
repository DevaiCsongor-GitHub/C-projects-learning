﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ConsoleApp1
{
    class Távolugrás
    {
        public string nev; //public - az egész programban elérhető
        public int tav;

        public Távolugrás(string s)
        {
            string[] sor = s.Split(';');
            nev = sor[0];
            tav = int.Parse(sor[1]);

        }
    }

    class Verseny
    {
        List<Távolugrás> lista;

        public Verseny(string filenev)
        {
            lista = new List<Távolugrás>();
            StreamReader sr = new StreamReader(filenev);
            while(!sr.EndOfStream)
            {
                lista.Add(new Távolugrás(sr.ReadLine()));
            }
        }
        public void kiir()
        {
            foreach (var item in lista)
            {
                Console.WriteLine(item.nev + " " + item.tav);
            }
        }
    }

    class Program
    {
        static void Main(string[] args) // <--eljárás
        {
            Verseny v =new Verseny(tavol.txt);
            v.kiir();
            Console.ReadKey();
        }
    }
}
