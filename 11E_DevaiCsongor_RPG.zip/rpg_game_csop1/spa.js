let profile = {
    "btn":document.getElementById("character_btn"),
    "page":document.getElementById("profile_page")
}

let adventure = {
    "btn": document.getElementById("adventure_btn"),
    "page": document.getElementById("adventure_page")
}

let dungeon = {
	"btn": document.getElementById("dungeon_btn"),
	"page": document.getElementById("dungeon_page")
}

function init(){
    switch_to_profile();
}

function switch_to_adventure(){
	dungeon.page.style.display = "none";
    dungeon.btn.style.display = "none";
    adventure.page.style.display = "block";
    adventure.btn.style.display = "none";
    profile.page.style.display = "none";
    profile.btn.style.display = "inline";
}
function switch_to_dungeon(){
	adventure.page.style.display = "none";
    adventure.btn.style.display = "none";
    dungeon.page.style.display = "block";
    dungeon.btn.style.display = "none";
    profile.page.style.display = "none";
    profile.btn.style.display = "inline";
}
function switch_to_profile(){
    adventure.page.style.display = "none";
    adventure.btn.style.display = "inline";
	dungeon.page.style.display = "none";
    dungeon.btn.style.display = "inline";
    profile.page.style.display = "block";
    profile.btn.style.display = "none";
}

init();