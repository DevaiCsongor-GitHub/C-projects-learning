let stats = {
	"lvl":0,
    "life": 100,
	"maxlife":100,
    "strength": 10,
    "endurance": 10,
    "deffense": 10,
    "experience": 0,
	"next_level": 10,
}

let available_points = 0;

let lvl = 0;

let lvl_description = [
    ["Egy gyenge kis csontváz vagy a katakombák mélyéből.", "profile_lvl0.jpg"],
    ["Egy veszélyes harcossá váltál!","profile_lvl1.jpg"],
    ["Az összetartó varázslat már alig tudja fékezni az erődet","profile_lvl2.jpg"],
    ["A lidércek mestere, a katakombák ura. Szinte lehetetlen negyőzni téged.", "profile_lvl3.jpg"],
	['"God of Bones"', "profile_lvl4.png"],
];

let profile_stats = {
    "pics": document.getElementById("profile_pics"),
    "description": document.getElementById("description"),
	"lvl": document.getElementById("profile_lvl"),
    "life": document.getElementById("profile_life"),
	"maxlife": document.getElementById("profile_maxlife"),
    "strength": document.getElementById("profile_strength"),
    "endurance": document.getElementById("profile_endurance"),
    "deffense": document.getElementById("profile_deffense"),
    "experience": document.getElementById("profile_experience"),
    "next_level": document.getElementById("next_lvl")
}

function refreshProfileStats(){
    profile_stats.pics.src = "pics/"+lvl_description[lvl][1]
	profile_stats.lvl.innerHTML = stats.lvl;
    profile_stats.life.innerHTML = stats.life;
	profile_stats.maxlife.innerHTML = stats.maxlife;
    profile_stats.strength.innerHTML = stats.strength;
    profile_stats.endurance.innerHTML = stats.endurance;
    profile_stats.deffense.innerHTML = stats.deffense;
    profile_stats.experience.innerHTML = stats.experience;
    profile_stats.description.innerHTML = lvl_description[lvl][0];
    profile_stats.next_level.innerHTML = stats.next_level;
    display_addBtns();
}

refreshProfileStats();

function update_strength(){
    if(available_points > 0){
        available_points--;
        stats.strength += 5;
        refreshProfileStats();
    }
}
function update_endurance(){
    if(available_points > 0){
        available_points--;
        stats.endurance += 5;
        refreshProfileStats();
    }
}
function update_deffense(){
    if(available_points > 0){
        available_points--;
        stats.deffense += 5;
        refreshProfileStats();
    }
}

function display_addBtns(){
    let btns = document.getElementsByClassName("addButtons");
    if(available_points > 0){
        for (let i = 0; i < btns.length; i++) {
            const element = btns[i];
            element.style.display="inline";
        }
    } else{
        for (let i = 0; i < btns.length; i++) {
            const element = btns[i];
            element.style.display="none";
        }
    }
}

function dead(){
    document.getElementById("character_btn").style.display = "none";
    document.getElementById("profile_page").style.display = "block";
    document.getElementById("adventure_btn").style.display = "none";
    document.getElementById("adventure_page").style.display = "none";
	document.getElementById("dungeon_btn").style.display = "none";
	document.getElementById("dungeon_page").style.display = "none";
	document.getElementById("levelup_btn").style.display = "none"
	document.getElementById("name").innerHTML = "MEGHALTÁL!!!";
}

function lvl_up(){
    if(lvl < lvl_description.length - 1 && stats.experience >= stats.next_level){
        available_points += 5;
        lvl++;
		stats.lvl++;
		stats.maxlife += 150;
		stats.life = stats.maxlife;
		stats.experience = 0;
		stats.next_level *= 1.5;
		if(lvl == 4)
		{
			stats.life = 9000;
			stats.maxlife = 9000;
			stats.deffense = 200;
			stats.endurance = 200;
			stats.strength = 200;
		}
        refreshProfileStats();
    }
}

/* ADVENTURE */

let story = document.getElementById("story");
let tortenet = document.getElementById("tortenet");

function rnd_szazalek(){
    return Math.floor(Math.random()*100);
}

function kaszalas(){
    let szazalek = rnd_szazalek();
    let sebzes_eselye = 50 - stats.deffense;

    if(sebzes_eselye <= 0) sebzes_eselye = 1;

    if(szazalek >= sebzes_eselye){
        // story.innerHTML += "Megsebződtél (-1 élet)<br>";
        // stats.life -= 1;
        fight("Kutya", 5, 25);
        refreshProfileStats();
    }else{
        story.innerHTML += "Tapasztalatot szereztél! (+1)<br>";
        stats.experience += 1;
        refreshProfileStats();
    }
}

function kutatas(){
	let szazalek = rnd_szazalek();
	tortenet.innerHTML = "Elkezdtél keresgélni.<br>";
	if (szazalek > 35){
		tortenet.innerHTML += "Nem találtál semmit!<br>";
	}
	else if(szazalek <= 5){
		tortenet.innerHTML += "A mestered megharagszik rád és megbüntet (-5 Élet)<br>";
		stats.life -= 5;
	}
	else if(szazalek > 5 && szazalek <= 15){
		tortenet.innerHTML += "Találtál pár rozsdás fegyvert (+1 sebzés)<br>";
		stats.strength += 2;
	}
	else if(szazalek > 15 && szazalek <= 25){
		tortenet.innerHTML += "találtál egy lyukas páncéldarabot (+1 védekezés)<br>";
		stats.deffense += 2;
	}
	else if(szazalek > 25 && szazalek <= 35){
		"találtál egy fényes kavicsot. Nem tudod mire jó de elteszed (+1 Kitartás)<br>";
		stats.endurance += 2;
	}
	else{}
	refreshProfileStats();
}

function gyogyitas(){
	if(stats.experience >= 2){
		stats.life = stats.maxlife;
		stats.experience -= 2;
		tortenet.innerHTML = "A rituálé sikerrel járt!<br>";
		tortenet.innerHTML += "<img src =./pics/medicine.jpg></img>";
	}
	else
	{
		tortenet.innerHTML = "Nincs elég tapasztalatod!<br>";
	}
	refreshProfileStats();
}

function fight(e_name, e_damage, e_life){
    story.innerHTML = "Amíg a parasztokat kergetted megtámadott téged egy " + e_name + "!<br>";

    let counter = 0;
    let enemy_attack = true;

    do {
        counter++;
        if(enemy_attack){
            // ellenfél támad
            let szazalek = rnd_szazalek();
            let sebzes_eselye = 40 - stats.deffense;
            if(sebzes_eselye <= 0) sebzes_eselye = 1;

            if(szazalek >= sebzes_eselye){
                story.innerHTML += "Ellenfeled rád ront! (-"+e_damage+" élet)<br>";
                stats.life -= e_damage;
				if (stats.life <= 0)
				{
					dead();
				}
                refreshProfileStats();
            }else{
                story.innerHTML += "Sikeresen elkerülöd ellenfeled csapását!<br>";
            }
            
        }else{
            let szazalek = rnd_szazalek();
            let sebzes_eselye = 40 + stats.endurance;
            if(sebzes_eselye >= 100) sebzes_eselye = 99;
            if(szazalek >= sebzes_eselye){
                story.innerHTML += "Rátámadsz ellenfeledre! ("+e_name+" -"+stats.strength+" élet)<br>";
                e_life -= stats.strength;
                story.innerHTML += e_name + "-nek maradt " + e_life+ "<br>";
				if (e_life <= 0)
				{
					story.innerHTML += "Legyőzted a "+e_name+"-t (+1 tapasztalat)<br>";
					stats.experience += 1;
					refreshProfileStats();
					break;
				}
                refreshProfileStats();
				
            }else{
                story.innerHTML += "Ellenfeled sikeresen kikerül a csapásodat!<br>";
            }
        }

        enemy_attack = !enemy_attack;
        
    } while (counter <=  10);
}