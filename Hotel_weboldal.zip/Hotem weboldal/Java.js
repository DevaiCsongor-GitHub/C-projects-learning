
var p1 = 0*1;
var p2 = 0*1;
var p3 = 0*1;

function myfirstfunction()
{
	p1 = document.getElementById("nap").value;
	p2 = document.getElementById("szob").value;
	p3 = (p1 * p2) * 20;
	document.getElementById("ar").innerHTML ="Ár: " + p3 + " Euro";
}

function mysecundfunction()
{
	alert("A foglalás sikeres!");
}